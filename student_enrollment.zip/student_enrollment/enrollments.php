<?php
include 'db.php';

if (isset($_POST['enroll'])) {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];

    $status_check = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT status FROM students WHERE student_id=$student_id")
    );

    if ($status_check['status'] != 'active') {
        echo "<script>alert('Only active students can enroll');</script>";
    } else {
        $seat_check = mysqli_fetch_row(
            mysqli_query($conn, "SELECT COUNT(*) FROM enrollments WHERE course_id=$course_id")
        );

        $max_seats = mysqli_fetch_row(
            mysqli_query($conn, "SELECT max_seats FROM courses WHERE course_id=$course_id")
        );

        if ($seat_check[0] >= $max_seats[0]) {
            echo "<script>alert('Course is full');</script>";
        } else {
            mysqli_query($conn, "INSERT INTO enrollments 
            (student_id, course_id, enrollment_date, status)
            VALUES ($student_id, $course_id, CURDATE(), 'enrolled')");
        }
    }
}

if (isset($_GET['delete'])) {
    mysqli_query($conn, "DELETE FROM enrollments WHERE enrollment_id={$_GET['delete']}");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Enrollments</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header><h1>Student Enrollment System</h1></header>

<nav>
    <a href="index.php">Home</a>
    <a href="students.php">Students</a>
    <a href="courses.php">Courses</a>
    <a href="enrollments.php">Enrollments</a>
    <a href="departments.php">Departments</a>
    <a href="reports.php">Reports</a>
</nav>

<div class="container">
    <h2>Enroll Student</h2>

    <form method="post">
        <select name="student_id" required>
            <option value="">Select Student</option>
            <?php
            $students = mysqli_query($conn, "SELECT * FROM students");
            while ($s = mysqli_fetch_assoc($students)) {
                echo "<option value='{$s['student_id']}'>{$s['first_name']} {$s['last_name']}</option>";
            }
            ?>
        </select>

        <select name="course_id" required>
            <option value="">Select Course</option>
            <?php
            $courses = mysqli_query($conn, "SELECT * FROM courses");
            while ($c = mysqli_fetch_assoc($courses)) {
                echo "<option value='{$c['course_id']}'>{$c['course_name']}</option>";
            }
            ?>
        </select>

        <button name="enroll">Enroll</button>
    </form>

    <h2>Enrollment Records</h2>

    <table>
        <tr>
            <th>Student</th>
            <th>Course</th>
            <th>Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php
        $enrollments = mysqli_query($conn, "
            SELECT e.enrollment_id, s.first_name, s.last_name, c.course_name, e.enrollment_date, e.status
            FROM enrollments e
            JOIN students s ON e.student_id = s.student_id
            JOIN courses c ON e.course_id = c.course_id
        ");

        while ($e = mysqli_fetch_assoc($enrollments)) {
            echo "<tr>
                <td>{$e['first_name']} {$e['last_name']}</td>
                <td>{$e['course_name']}</td>
                <td>{$e['enrollment_date']}</td>
                <td>{$e['status']}</td>
                <td><a class='delete-btn' href='enrollments.php?delete={$e['enrollment_id']}'>Delete</a></td>
            </tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
