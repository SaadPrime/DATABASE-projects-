<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "student_enrollment_system");

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
