<?php
include 'db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Student Enrollment System</h1></header>
<nav>
    <a href="index.php">Home</a>
    <a href="students.php">Students</a>
    <a href="courses.php">Courses</a>
    <a href="enrollments.php">Enrollments</a>
    <a href="departments.php">Departments</a>
    <a href="reports.php">Reports</a>
</nav>
<div class="container">
    <h2>Reports</h2>

    <h3>1. Students Per Course</h3>
    <table>
        <tr><th>Course</th><th>Department</th><th>Enrolled Students</th></tr>
        <?php
        $query = mysqli_query($conn, "
            SELECT c.course_name, d.department_name, COUNT(e.student_id) AS total_students
            FROM courses c
            LEFT JOIN departments d ON c.department_id = d.department_id
            LEFT JOIN enrollments e ON c.course_id = e.course_id AND e.enrollment_status='enrolled'
            GROUP BY c.course_id
        ");
        while($row = mysqli_fetch_assoc($query)){
            echo "<tr>
            <td>{$row['course_name']}</td>
            <td>{$row['department_name']}</td>
            <td>{$row['total_students']}</td>
            </tr>";
        }
        ?>
    </table>

    <h3>2. Courses Per Department</h3>
    <table>
        <tr><th>Department</th><th>Total Courses</th></tr>
        <?php
        $query = mysqli_query($conn, "
            SELECT d.department_name, COUNT(c.course_id) AS total_courses
            FROM departments d
            LEFT JOIN courses c ON d.department_id = c.department_id
            GROUP BY d.department_id
        ");
        while($row = mysqli_fetch_assoc($query)){
            echo "<tr>
            <td>{$row['department_name']}</td>
            <td>{$row['total_courses']}</td>
            </tr>";
        }
        ?>
    </table>

    <h3>3. Students Per Department</h3>
    <table>
        <tr><th>Department</th><th>Total Students</th></tr>
        <?php
        $query = mysqli_query($conn, "
            SELECT d.department_name, COUNT(s.student_id) AS total_students
            FROM departments d
            LEFT JOIN students s ON d.department_id = s.department_id
            GROUP BY d.department_id
        ");
        while($row = mysqli_fetch_assoc($query)){
            echo "<tr>
            <td>{$row['department_name']}</td>
            <td>{$row['total_students']}</td>
            </tr>";
        }
        ?>
    </table>

</div>
</body>
</html>
