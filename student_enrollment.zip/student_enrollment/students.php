<?php
include 'db.php';

// Add Student
if(isset($_POST['add_student'])){
    $stu_num = $_POST['student_number'];
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $email = $_POST['email'];
    $dept_id = $_POST['department_id'];

    mysqli_query($conn, "INSERT INTO students (student_number, first_name, last_name, email, department_id) VALUES ('$stu_num','$fname','$lname','$email',$dept_id)");
}

// Delete Student
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM students WHERE student_id=$id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Students</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Student Enrollment System</h1></header>
<nav>
    <a href="index.php">Home</a>
    <a href="students.php">Students</a>
    <a href="courses.php">Courses</a>
    <a href="enrollments.php">Enrollments</a>
    <a href="departments.php">Departments</a>
    <a href="reports.php">Reports</a>
</nav>
<div class="container">
    <h2>Add Student</h2>
    <form method="post">
        <input type="text" name="student_number" placeholder="Student Number" required>
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="email" name="email" placeholder="Email" required>

        <select name="department_id" required>
            <option value="">Select Department</option>
            <?php
            $depts = mysqli_query($conn, "SELECT * FROM departments");
            while($d = mysqli_fetch_assoc($depts)) {
                echo "<option value='{$d['department_id']}'>{$d['department_name']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="add_student">Add Student</button>
    </form>

    <h2>Students List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Action</th>
        </tr>
        <?php
        $result = mysqli_query($conn, 
            "SELECT s.student_id, s.student_number, s.first_name, s.last_name, s.email, d.department_name 
             FROM students s
             LEFT JOIN departments d ON s.department_id = d.department_id"
        );
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
            <td>{$row['student_id']}</td>
            <td>{$row['student_number']}</td>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['email']}</td>
            <td>{$row['department_name']}</td>
            <td><a class='delete-btn' href='students.php?delete={$row['student_id']}'>Delete</a></td>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
