<?php
include 'db.php';

// Add Department
if(isset($_POST['add_department'])){
    $name = $_POST['department_name'];
    $head = $_POST['head_of_department'];
    mysqli_query($conn, "INSERT INTO departments (department_name, head_of_department) VALUES ('$name','$head')");
}

// Delete Department
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM departments WHERE department_id=$id");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Departments</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Student Enrollment System</h1></header>
<nav>
    <a href="index.php">Home</a>
    <a href="students.php">Students</a>
    <a href="courses.php">Courses</a>
    <a href="enrollments.php">Enrollments</a>
    <a href="departments.php">Departments</a>
    <a href="reports.php">Reports</a>
</nav>
<div class="container">
    <h2>Add Department</h2>
    <form method="post">
        <input type="text" name="department_name" placeholder="Department Name" required>
        <input type="text" name="head_of_department" placeholder="Head of Department">
        <button name="add_department">Add Department</button>
    </form>

    <h2>Departments List</h2>
    <table>
        <tr><th>ID</th><th>Name</th><th>Head</th><th>Action</th></tr>
        <?php
        $result = mysqli_query($conn,"SELECT * FROM departments");
        while($row=mysqli_fetch_assoc($result)){
            echo "<tr>
            <td>{$row['department_id']}</td>
            <td>{$row['department_name']}</td>
            <td>{$row['head_of_department']}</td>
            <td><a class='delete-btn' href='departments.php?delete={$row['department_id']}'>Delete</a></td>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
