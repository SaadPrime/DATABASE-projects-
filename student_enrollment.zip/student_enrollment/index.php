<!DOCTYPE html>
<html>
<head>
    <title>Student Enrollment System</title>
</head>
<body>
    <h1>Student Enrollment System</h1>
    <ul>
        <li><a href="students.php">Students</a></li>
        <li><a href="courses.php">Courses</a></li>
        <li><a href="enrollments.php">Enrollments</a></li>
    </ul>
</body>
</html>
