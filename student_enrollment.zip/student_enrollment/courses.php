<?php
include 'db.php';

// Add Course
if(isset($_POST['add_course'])){
    $course_name = $_POST['course_name'];
    $course_code = $_POST['course_code'];
    $credits = $_POST['credits'];
    $department_id = $_POST['department_id'];

    mysqli_query($conn, "INSERT INTO courses (course_name, course_code, credits, department_id) VALUES ('$course_name','$course_code','$credits',$department_id)");
}

// Delete Course
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM courses WHERE course_id=$id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Courses</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header><h1>Student Enrollment System</h1></header>
<nav>
    <a href="index.php">Home</a>
    <a href="students.php">Students</a>
    <a href="courses.php">Courses</a>
    <a href="enrollments.php">Enrollments</a>
    <a href="departments.php">Departments</a>
    <a href="reports.php">Reports</a>
</nav>
<div class="container">
    <h2>Add Course</h2>
    <form method="post">
        <input type="text" name="course_name" placeholder="Course Name" required>
        <input type="text" name="course_code" placeholder="Course Code" required>
        <input type="number" name="credits" placeholder="Credits" required>

        <select name="department_id" required>
            <option value="">Select Department</option>
            <?php
            $depts = mysqli_query($conn, "SELECT * FROM departments");
            while($d = mysqli_fetch_assoc($depts)){
                echo "<option value='{$d['department_id']}'>{$d['department_name']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="add_course">Add Course</button>
    </form>

    <h2>Courses List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Course Name</th>
            <th>Course Code</th>
            <th>Credits</th>
            <th>Department</th>
            <th>Action</th>
        </tr>
        <?php
        $result = mysqli_query($conn, "
            SELECT c.course_id, c.course_name, c.course_code, c.credits, d.department_name
            FROM courses c
            LEFT JOIN departments d ON c.department_id = d.department_id
        ");
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr>
            <td>{$row['course_id']}</td>
            <td>{$row['course_name']}</td>
            <td>{$row['course_code']}</td>
            <td>{$row['credits']}</td>
            <td>{$row['department_name']}</td>
            <td><a class='delete-btn' href='courses.php?delete={$row['course_id']}'>Delete</a></td>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
